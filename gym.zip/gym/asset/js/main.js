$(document).ready(function() {

	$('.counter').counterUp({
        delay: 10,
        time: 1000
    });
    $('.single-gallery-overley > a').magnificPopup({type:'image'});

    $('.team').owlCarousel({
	    loop:true,
	    margin:0,
		autoplay:true,
	    nav:true,
		dost:false,
		smartSpeed:1000,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:4
	        }
	    }
	});
	$('.class').owlCarousel({
	    loop:true,
	    margin:0,
		autoplay:true,
	    nav:true,
		dost:false,
		smartSpeed:1000,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:3
	        }
	    }
	});
	$('.testimonail').owlCarousel({
	    loop:true,
	    margin:0,
		autoplay:true,
	    nav:false,
		dost:true,
		smartSpeed:1000,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:1
	        },
	        1000:{
	            items:1
	        }
	    }
	});
	$('.blog').owlCarousel({
	    loop:true,
	    margin:0,
		autoplay:true,
	    nav:true,
		dost:false,
		smartSpeed:1000,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:3
	        }
	    }
	});
});



$(document).ready(function(){
  $('body').scrollspy({target: ".navbar", offset: 80});   
  $(".menu a, .down-btn a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;

      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 1000, function(){
       
      });
    }  
  });

  $('.isotop-item').isotope({
    itemSelector: '.item',
    LayoutMode: 'fitRows'
});
$('.isotop ul li').click(function(){
    $('.isotop ul li').removeClass('active');
    $(this).addClass('active');
    
    var selector = $(this).attr('data-filter');
    $('.isotop-item').isotope({
        filter: selector
    });
    return false;
});

$(window).scroll(function(){
    var halcyan = $(window).scrollTop();
    if(halcyan>20){
        $('.header-top-area').addClass('ht-sticky');
    }
    else{
        $('.header-top-area').removeClass('ht-sticky');
    }

    $('.isotop-oveley > a').magnificPopup({type:'image'});
});

$('.scrolltop').on('click', function(e){
	$('html').animate({
		'scrollTop':0
	},1000);
	return false;
});
$(window).scroll(function(){
    var halcyan = $(window).scrollTop();
    if(halcyan>400){
        $('.scrolltop').slideDown(1000);
    }
    else{
        $('.scrolltop').slideUp(1000);
    }

});

});